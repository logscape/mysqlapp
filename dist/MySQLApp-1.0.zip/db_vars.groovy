import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import groovy.sql.Sql



pout = pout == null ? System.out : pout
perr = perr == null ? System.err : perr

def stdOut = pout
def stdErr = perr
Logger logger = new Logger()
logger.setOutStream(pout)
logger.setErrStream(perr)


def propertyMissing(String name) {}

 
def arguments  =  args  as List 
def properties= null;


if (arguments!=null) {
	properties=new ExecutionContext(arguments) 
}else{
	properties=new ExecutionContext(arguments,_bindings) 
} 

defaultUser=properties.map["defaultUser"]		// defaultUser
defaultPassword=properties.map["defaultPassword"]	// defaultPassword 
hostnames=properties.map["hostnames"].split(",")   // user:password@hostname 
def resultSet=[:]



for(def hostname:hostnames){
        if (hostname=="127.0.0.1") {
                hostname=java.net.InetAddress.getLocalHost().getHostName()
        }

	def url = "jdbc:mysql://"+hostname+"/mysql?user="+defaultUser+"&password="+defaultPassword+"";
	def sql = Sql.newInstance(url) 
	resultSet[hostname]=[:]
	resultSet[hostname]["sql"]=sql
}


query="show global variables;"
def oldMap = [:]

def hardWait=60
def softWait=15
def waited=0
while (true) { 
	for(def hostname:resultSet.keySet()){
		def map=["_":"_","hostname":hostname]
		def sql= resultSet[hostname].sql
		map << metrics_prepare(sql) 
		//logger.logkv(map)
		def deltaMap=MetricDiffOp.go(oldMap,map) 
		if( waited % hardWait == 0 )  { 
			waited = 0 
			logger.logkv(map) 
		} else {
			if (deltaMap.size() > 0) {
				logger.logkv( ["_":"_", "hostname":hostname ] << deltaMap)
			}
		
		}
			
		oldMap = map 
	}

	sleep softWait*1000 
	waited+=softWait
}

//MetricDiffOp.go(prevMetrics,currMetrics)
System.exit(0) 


def metrics_prepare(sql){
	def map=[:]
	sql.eachRow(query) {
		def k = it[0] // "VARIABLE_NAME"] 
		def v = it[1] // "VARIABLE_VALUE"]
		map[k]=v
		
	}
	return map 

}
